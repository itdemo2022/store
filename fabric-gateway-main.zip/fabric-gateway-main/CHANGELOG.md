# Changelog

Notable changes in each release are documented on the project's [GitHub releases](https://github.com/hyperledger/fabric-gateway/releases) page.
